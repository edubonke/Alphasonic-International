#!/usr/bin/env bash
set -euo pipefail

REPO_DIR="${1:-/workspaces/Alphasonic-International}"
PACKAGE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
EXPECTED_HEAD="e72e3f5144e031d4cd6934afa9dce69de4527bc5"

if [[ ! -d "$REPO_DIR/.git" ]]; then
  echo "ERROR: Git repository not found at: $REPO_DIR"
  exit 1
fi

cd "$REPO_DIR"

git fetch origin
git pull --ff-only origin main

CURRENT_HEAD="$(git rev-parse HEAD)"
if [[ "$CURRENT_HEAD" != "$EXPECTED_HEAD" ]]; then
  echo "ERROR: main has changed since this integration package was prepared."
  echo "Expected: $EXPECTED_HEAD"
  echo "Current:  $CURRENT_HEAD"
  echo "No files were copied. Ask ChatGPT to rebuild the integration against the new HEAD."
  exit 2
fi

cp "$PACKAGE_DIR/index.html" ./index.html
cp "$PACKAGE_DIR/media-gallery.css" ./media-gallery.css

mkdir -p assets/projects assets/optimized assets/video
cp "$PACKAGE_DIR"/assets/projects/*.jpg assets/projects/
cp "$PACKAGE_DIR"/assets/optimized/*.webp assets/optimized/
cp "$PACKAGE_DIR"/assets/video/* assets/video/

node --check script.js
node --check pricing-config.js
node --check analytics.js

git diff --check

python3 - <<'PY'
from pathlib import Path
from html.parser import HTMLParser
import json, re

class CheckHTML(HTMLParser):
    pass

html = Path('index.html').read_text(encoding='utf-8')
CheckHTML().feed(html)

required = [
    '04 / Exterior refurbishment',
    '05 / Interior refurbishment',
    '06 / Bathroom upgrade',
    'exterior-renovation-walkthrough.mp4',
    'exterior-painting-scaffold-progress.mp4',
    'media-gallery.css',
    'pricing-config.js',
    'script.js',
    'analytics.js',
    'G-P7XPQTSGKJ',
    'Quality Builds. Lasting Value.',
    'Global Solutions. Local Support.',
    'Built right. Built to last.'
]

for item in required:
    if item not in html:
        raise SystemExit(f'ERROR: required integration content missing: {item}')

# Check every new local media reference exists.
refs = set(re.findall(r'(?:src|poster|data-gallery-src)="(assets/[^"]+)"', html))
missing = [r for r in refs if any(x in r for x in [
    'exterior-main-facade-existing-condition',
    'exterior-garden-facade-existing-condition',
    'exterior-patio-existing-condition',
    'exterior-scaffold-painting-progress',
    'interior-board-cutting-progress',
    'interior-surface-preparation-progress',
    'interior-wall-painting-progress',
    'interior-wall-finish-complete',
    'bathroom-shower-complete',
    'bathroom-bath-complete',
    'exterior-renovation-walkthrough'
]) and not Path(r).exists()]

if missing:
    raise SystemExit('ERROR: missing media files:\n' + '\n'.join(missing))

print('Media integration checks passed.')
PY

echo
echo "===== CHANGED FILES ====="
git status --short

echo
echo "===== DIFF SUMMARY ====="
git --no-pager diff --stat

echo
echo "Integration applied locally and validated."
echo "Review the site, then commit with:"
echo "  git add index.html media-gallery.css assets/projects assets/optimized assets/video"
echo "  git commit -m \"Expand portfolio with additional project media\""
echo "  git push origin main"
