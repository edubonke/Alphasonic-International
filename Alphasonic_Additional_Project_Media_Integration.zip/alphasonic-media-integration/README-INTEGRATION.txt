ALPHASONIC INTERNATIONAL — ADDITIONAL PROJECT MEDIA INTEGRATION

This package adds the supplied project photographs and videos without removing
any existing portfolio content.

New portfolio groups:
04 / Exterior refurbishment
- Existing-condition property views
- Scaffold access / painting progress photograph
- Exterior progress walkthrough video
- Scaffold painting progress video

05 / Interior refurbishment
- Board cutting / preparation
- Wall patching and preparation
- Interior painting in progress
- Completed wall finish

06 / Bathroom upgrade
- Completed tiled shower view
- Completed bath / toilet / tiled-wall view

Performance and accessibility choices:
- Supplied JPG files are preserved as lightbox sources.
- 640px and 960px WebP display derivatives are included for normal page loads.
- Videos are compressed to H.264 MP4 with fast-start and preload=metadata.
- Web video derivatives are intentionally silent; the original uploads are not modified.
- Video posters are included so clips do not download until the visitor chooses to play.
- New images use descriptive alt text and captions.
- Existing branding, estimator, GA4 tracking, SEO metadata, accessibility logic,
  and existing project portfolio remain in place.

The install script is guarded against overwriting a newer main branch. It expects
HEAD e72e3f5144e031d4cd6934afa9dce69de4527bc5.
