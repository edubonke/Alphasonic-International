ALPHASONIC INTERNATIONAL — SERVICE CARD VISUALS

This package fixes the previous /mnt/data issue: the ChatGPT working directory is not your GitHub Codespace, so these assets must be uploaded into the Codespace first.

Visual-source policy used:
- Painting: existing real Alphasonic project photo already in the repository.
- Plumbing: existing real bathroom project photo already in the repository.
- Renovations: existing real kitchen-renovation project photo already in the repository.
- Electrical: AI-generated representative service visual.
- Ceilings: AI-generated representative service visual.
- Shop Fitting: AI-generated representative service visual.

The service cards retain their data-service attributes and button behavior, so clicking them still opens/selects the matching quote estimator service.

INSTALL
1. Upload this ZIP to the root of the Codespace repository.
2. Run:

   cd /workspaces/Alphasonic-International
   unzip -o Alphasonic_Service_Card_Visuals_Integration.zip
   bash alphasonic-service-visuals-integration/apply-service-visuals.sh

3. Review git status and diff.
4. Commit:

   git add index.html styles.css assets/services
   git commit -m "Replace service icons with representative visuals"
   git push origin main

The installer is pinned to repository HEAD:
d84359fdcb1039161278ca16f47d1119b264d40c

If main changes before you run it, it stops without changing website files.
