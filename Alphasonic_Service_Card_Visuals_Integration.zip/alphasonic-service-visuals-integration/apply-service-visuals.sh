#!/usr/bin/env bash
set -euo pipefail

EXPECTED_HEAD="d84359fdcb1039161278ca16f47d1119b264d40c"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(pwd)"

if [[ ! -f "$REPO_DIR/index.html" || ! -f "$REPO_DIR/styles.css" ]]; then
  echo "ERROR: Run this script from the root of the Alphasonic-International repository."
  exit 1
fi

git fetch origin main >/dev/null 2>&1 || true
CURRENT_HEAD="$(git rev-parse HEAD)"

if [[ "$CURRENT_HEAD" != "$EXPECTED_HEAD" ]]; then
  echo "ERROR: main has changed since this service-visual package was prepared."
  echo "Expected: $EXPECTED_HEAD"
  echo "Current:  $CURRENT_HEAD"
  echo "No website files were changed. Ask ChatGPT to rebuild the package against the new HEAD."
  exit 2
fi

mkdir -p assets/services
cp "$SCRIPT_DIR"/assets/services/*.webp assets/services/

python3 - <<'PY'
from pathlib import Path
import re

index_path = Path('index.html')
styles_path = Path('styles.css')
html = index_path.read_text(encoding='utf-8')
css = styles_path.read_text(encoding='utf-8')

cards = {
    'painting': '''<span class="service-visual service-visual-real" aria-hidden="true">
              <img
                src="assets/optimized/residential-interior-painting-progress-640.webp"
                srcset="assets/optimized/residential-interior-painting-progress-640.webp 640w, assets/optimized/residential-interior-painting-progress-1200.webp 1200w"
                sizes="(max-width: 640px) calc(100vw - 56px), (max-width: 1024px) 46vw, 29vw"
                width="640" height="640" alt="" loading="lazy" decoding="async" />
              <span class="service-visual-badge">Real project</span>
            </span>''',
    'plumbing': '''<span class="service-visual service-visual-real" aria-hidden="true">
              <img
                src="assets/optimized/bathroom-bath-complete-640.webp"
                srcset="assets/optimized/bathroom-bath-complete-640.webp 640w, assets/optimized/bathroom-bath-complete-960.webp 960w"
                sizes="(max-width: 640px) calc(100vw - 56px), (max-width: 1024px) 46vw, 29vw"
                width="640" height="640" alt="" loading="lazy" decoding="async" />
              <span class="service-visual-badge">Real project</span>
            </span>''',
    'electrical': '''<span class="service-visual service-visual-representative" aria-hidden="true">
              <img
                src="assets/services/electrical-480.webp"
                srcset="assets/services/electrical-480.webp 480w, assets/services/electrical-800.webp 800w"
                sizes="(max-width: 640px) calc(100vw - 56px), (max-width: 1024px) 46vw, 29vw"
                width="800" height="800" alt="" loading="lazy" decoding="async" />
              <span class="service-visual-badge">Representative visual</span>
            </span>''',
    'ceilings': '''<span class="service-visual service-visual-representative" aria-hidden="true">
              <img
                src="assets/services/ceilings-480.webp"
                srcset="assets/services/ceilings-480.webp 480w, assets/services/ceilings-800.webp 800w"
                sizes="(max-width: 640px) calc(100vw - 56px), (max-width: 1024px) 46vw, 29vw"
                width="800" height="800" alt="" loading="lazy" decoding="async" />
              <span class="service-visual-badge">Representative visual</span>
            </span>''',
    'shopfitting': '''<span class="service-visual service-visual-representative" aria-hidden="true">
              <img
                src="assets/services/shop-fitting-480.webp"
                srcset="assets/services/shop-fitting-480.webp 480w, assets/services/shop-fitting-800.webp 800w"
                sizes="(max-width: 640px) calc(100vw - 56px), (max-width: 1024px) 46vw, 29vw"
                width="800" height="800" alt="" loading="lazy" decoding="async" />
              <span class="service-visual-badge">Representative visual</span>
            </span>''',
    'renovations': '''<span class="service-visual service-visual-real" aria-hidden="true">
              <img
                src="assets/optimized/kitchen-renovation-complete-01-640.webp"
                srcset="assets/optimized/kitchen-renovation-complete-01-640.webp 640w, assets/optimized/kitchen-renovation-complete-01-1200.webp 1200w"
                sizes="(max-width: 640px) calc(100vw - 56px), (max-width: 1024px) 46vw, 29vw"
                width="640" height="640" alt="" loading="lazy" decoding="async" />
              <span class="service-visual-badge">Real project</span>
            </span>''',
}

for service, visual in cards.items():
    button_pattern = re.compile(
        rf'(<button class="service-card"[^>]*data-service="{re.escape(service)}"[^>]*>)(.*?)(</button>)',
        re.S,
    )
    match = button_pattern.search(html)
    if not match:
        raise SystemExit(f'ERROR: service card not found for {service}')

    body = match.group(2)
    if 'class="service-visual ' in body:
        continue

    icon_pattern = re.compile(
        r'\s*<span class="service-icon" aria-hidden="true">.*?</span>\s*',
        re.S,
    )
    if not icon_pattern.search(body):
        raise SystemExit(f'ERROR: old icon block not found for {service}')

    body = icon_pattern.sub('\n            ' + visual + '\n            ', body, count=1)
    replacement = match.group(1) + body + match.group(3)
    html = html[:match.start()] + replacement + html[match.end():]

marker = '/* === Service card photographic visuals === */'
service_css = r'''

/* === Service card photographic visuals ===
   Real project photos are used where the supplied portfolio directly represents
   the service. AI-generated representative visuals are labelled as such. */
.service-card {
  min-height: 0;
  padding: 18px 18px 24px;
  overflow: hidden;
}

.service-visual {
  position: relative;
  display: block;
  width: 100%;
  aspect-ratio: 4 / 3;
  overflow: hidden;
  border: 1px solid #dfe8f1;
  border-radius: 16px;
  background: #edf3f8;
  box-shadow: 0 8px 22px rgba(3,26,59,.055);
}

.service-visual img {
  display: block;
  width: 100%;
  height: 100%;
  object-fit: cover;
  transition: transform .28s ease;
}

.service-visual-badge {
  position: absolute;
  left: 10px;
  bottom: 10px;
  max-width: calc(100% - 20px);
  padding: 6px 9px;
  border-radius: 999px;
  background: rgba(255,255,255,.94);
  box-shadow: 0 5px 16px rgba(3,26,59,.12);
  color: var(--navy-950);
  font-size: 9px;
  font-weight: 900;
  letter-spacing: .055em;
  line-height: 1;
  text-transform: uppercase;
}

.service-visual-representative .service-visual-badge {
  color: #44546a;
}

.service-title {
  margin-top: 18px;
}

.service-card:hover .service-visual img,
.service-card:focus-visible .service-visual img {
  transform: scale(1.025);
}

@media (max-width: 640px) {
  .service-card {
    padding: 14px 14px 20px;
  }

  .service-visual {
    border-radius: 14px;
  }
}

@media (prefers-reduced-motion: reduce) {
  .service-visual img {
    transition: none;
  }
}
'''

if marker not in css:
    css = css.rstrip() + service_css + '\n'

# Safety checks: service behavior remains button/data-service based.
for service in cards:
    if f'data-service="{service}"' not in html:
        raise SystemExit(f'ERROR: data-service lost for {service}')

for required in ['pricing-config.js', 'script.js', 'analytics.js', 'G-P7XPQTSGKJ']:
    if required not in html:
        raise SystemExit(f'ERROR: protected integration missing: {required}')

index_path.write_text(html, encoding='utf-8')
styles_path.write_text(css, encoding='utf-8')
print('Service visuals applied successfully.')
PY

node --check script.js
node --check analytics.js
node --check pricing-config.js
git diff --check

for f in \
  assets/services/electrical-480.webp \
  assets/services/electrical-800.webp \
  assets/services/ceilings-480.webp \
  assets/services/ceilings-800.webp \
  assets/services/shop-fitting-480.webp \
  assets/services/shop-fitting-800.webp; do
  [[ -f "$f" ]] || { echo "ERROR: Missing $f"; exit 3; }
done

echo
echo "Service visual integration applied locally and validated."
echo
echo "===== CHANGED FILES ====="
git status --short
echo
echo "===== DIFF SUMMARY ====="
git --no-pager diff --stat
